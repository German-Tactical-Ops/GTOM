/*
    Part of the TBMod ( https://github.com/TacticalBaconDevs/TBMod )
    Developed by http://tacticalbacon.de
*/
class CfgEditorSubcategories
{
    class EdSubcat_TB_Arsenal
    {
        displayName = "Arsenal";
    };
};
